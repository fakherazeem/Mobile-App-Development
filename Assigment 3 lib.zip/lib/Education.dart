import 'package:flutter/material.dart';

class Education extends StatelessWidget {
  const Education({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1224),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 40),
            const Text(
              'Education',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white, 
              ),
            ),
            const SizedBox(height: 20),
            buildEducationCard(
              'Graduation',
              'The University Of Lahore',
              'Bachelor of Science in Information Engineering Technology, BSIET (2022-2026).',
            ),
            buildEducationCard(
              'Intermediate',
              'KIPS College',
              'Fsc. (2018-2020)',
            ),
            buildEducationCard(
              'Matriculation',
              'Allied School',
              '(2016-2018)',
            ),
          ],
        ),
      ),
    );
  }

  Widget buildEducationCard(String title, String institution, String details) {
    return Card(
      elevation: 4,
      color: const Color(0xFF1A1F36),
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white, ),
            ),
            Text(
              institution,
              style: const TextStyle(
                fontSize: 18,
                color: Colors.white70, 
              ),
            ),
            Text(
              details,
              style: const TextStyle(
                color: Colors.white70, 
              ),
            ),
          ],
        ),
      ),
    );
  }
}
