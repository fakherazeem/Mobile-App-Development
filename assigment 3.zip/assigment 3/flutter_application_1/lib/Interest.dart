import 'package:flutter/material.dart';

class Interests extends StatelessWidget {
  const Interests({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1224), // Set dark blue background color
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 40),
            const Text(
              'Portfolio Interest Section',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.white, // Updated to white for better contrast
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'My Interests:',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white, // Updated to white for better contrast
              ),
            ),
            const SizedBox(height: 20),
            buildInterestItem(
              'Mobile App Development',
              'Creating innovative mobile applications.',
            ),
            buildInterestItem(
              'Machine Learning',
              'Exploring algorithms to extract insights from data.',
            ),
            buildInterestItem(
              'Cloud Computing',
              'Leveraging cloud platforms for efficient and scalable solutions.',
            ),
          ],
        ),
      ),
    );
  }

  Widget buildInterestItem(String title, String description) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white, 
            ),
          ),
          const SizedBox(height: 4),
          Text(
            description,
            style: const TextStyle(
              color: Colors.white70, 
            ),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
