// ignore_for_file: file_names

import 'package:flutter/material.dart';

class About extends StatelessWidget {
  const About({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1224), 
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              Center(),

              const SizedBox(height: 20),

              const Text(
                'M Fakhar Azeem',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.blueAccent,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Full Stack Developer | Flutter  | React Developer',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Colors.white, 
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  buildSocialIcon(Icons.facebook, 'Facebook', Colors.blue),
                  buildSocialIcon(Icons.camera_alt, 'Instagram', Colors.purple),
                  buildSocialIcon(
                      Icons.linked_camera, 'LinkedIn', Colors.blueAccent),
                ],
              ),

              const SizedBox(height: 30),

              const Text(
                'Hi! I’m a full-stack developer who build amazing web applications.',
                style: TextStyle(
                  fontSize: 16,
                  height: 1.5,
                  color: Colors.white, 
                ),
                textAlign: TextAlign.justify,
              ),

              const SizedBox(height: 30),


            ],
          ),
        ),
      ),
    );
  }

  Widget buildSocialIcon(IconData icon, String label, Color color) {
    return Column(
      children: [
        Icon(icon, size: 30, color: color),
        const SizedBox(height: 5),
        Text(
          label,
          style: const TextStyle(fontSize: 12, color: Colors.white), 
        ),
      ],
    );
  }
}
